# EventWidget Standalone

A fully self-contained, CMS-ready JavaScript event widget. Easily embed real-time event listings on any website or CMS using a single JS file and a CSV data source (including Google Sheets).

## Features
- No dependencies, no build step—just one JS file
- Works in any CMS or static HTML page
- Real-time updates via Google Sheets or any public CSV
- Beautiful, responsive UI with search and filtering

## Quick Start

### 1. Upload the Files
- Upload `EventWidget.standalone.js` to your CMS or web server.

### 2. Add the Widget to Your Page
```html
<!-- Include the widget script -->
<script src="/path/to/EventWidget.standalone.js"></script>

<!-- Widget container -->
<div id="event-widget-container"></div>

<!-- Initialize the widget -->
<script>
  new EventWidget(
    '#event-widget-container',
    'https://docs.google.com/spreadsheets/d/e/2PACX-1vQQHx-Kr5LuBIltWTdEXE-ezey3DV0hVuMFvWpZ-QIrtG9M-qfSsEnk420vntpBb68IqX_vY-CuohyK/pub?gid=249679331&single=true&output=csv',
    {
      showPastEvents: false, // Hide past events (default: false)
      autoRefresh: true     // Auto-refresh every minute (default: true)
    }
  );
</script>
```

### 3. Using a Google Sheet as Your Data Source
- Open your Google Sheet
- Go to **File > Share > Publish to web**
- Choose the sheet and select **Comma-separated values (.csv)**
- Copy the published CSV link and use it as the second argument to `EventWidget`

### 4. Using a Local CSV
- Upload your `events.csv` to your server or CMS
- Use the path to your CSV as the second argument

### 5. Options
| Option          | Type    | Default | Description                        |
|-----------------|---------|---------|------------------------------------|
| showPastEvents  | Boolean | false   | Show past events                   |
| autoRefresh     | Boolean | true    | Auto-refresh every minute          |

## Example Demo
See `demo.html` for a working example.

## License
MIT
